# DERIVA — Calculus, Made Visible

A rigorous, beautiful, intuitive calculus visualization site: drag tangents, slide Riemann sums, master ε-δ.

## Files
- `streamlit_app.py` — Streamlit entry point (deploy target)
- `deriva_app.html` — the full visualization site (HTML + CSS + JS inlined)
- `requirements.txt` — Python dependencies for Streamlit Community Cloud

## Deploy to Streamlit Community Cloud
1. Push this repo to GitHub.
2. Go to https://share.streamlit.io/deploy
3. Pick the repo, branch `main`, main file `streamlit_app.py`.
4. Click **Deploy**.

## Run locally
```bash
pip install -r requirements.txt
streamlit run streamlit_app.py
```
